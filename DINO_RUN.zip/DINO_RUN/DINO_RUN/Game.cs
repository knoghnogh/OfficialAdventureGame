﻿using System;
using System.Threading;
using static System.Console;



namespace DINO_RUN
{
    public class Game
    {
        private Dino raptor;

        //constructor
        public void StartGame()
        { 

            //initialize dinorun
            WriteLine("DinoRun");
            WriteLine("A young Raptor has escaped from a sinster laboratory,");
            WriteLine("its up to you to guide him out of the lab");
            nextLine();

            //name the character
            string name = nameCharacter();

            //make a dino with the given name
            raptor = new Dino(name);
            Clear();

            //play the game
            play();

        }

        public void play()
        {
            //declare variables
            Locations newLocation;
            

            //initialize variables
            Item food = new Item("food", "description");
            Item weapon = new Item("weapon", "description");
            bool repeat = true;
            string input = "a";

            //while repeat is true
            while (repeat)
            {

                //print out info for current location
                WriteLine("Where " + raptor.name + " is: ");
                WriteLine("    " + raptor.currentLocation.About());
                nextLine();

                //call locationMenu on currentLocation
                raptor.currentLocation.LocationMenu();
                nextLine();

                //prompt input
                input = ReadLine().ToLower();

                //prompt the user until the input is correct
                while (input != "a" && input != "b")
                {
                    //print error message
                    WriteLine("Please choose between A or B");
                    nextLine();

                    //call locationMenu on currentLocation
                    raptor.currentLocation.LocationMenu();
                    nextLine();

                    //prompt input
                    input = ReadLine().ToLower();
                }

                //change new location based off of what the user inputs
                if (input == "a")
                {
                    //set new location to option 1
                    newLocation = raptor.currentLocation.dest1;

                    //check if in storage
                    if (IsStorage())
                    {

                        //add food to dino inventory
                        raptor.inventory.Add(food);
                    }
                }
                else
                {
                    //set new location to option 2
                    newLocation = raptor.currentLocation.dest2;

                    //check if in storage
                    if (IsStorage())
                    {
                        //add food to dino inventory
                        raptor.inventory.Add(weapon);
                    }
                }

                //check if the game is over
                if (IsEnd())
                {
                    //set repeat to false
                    repeat = false;

                }
                else
                {
                    //if not, set current location to new location
                    raptor.currentLocation = newLocation;

                }

                //change colors
                BackgroundColor = raptor.currentLocation.locationColor;
                ForegroundColor = ConsoleColor.White;

                //clear the screen
                Clear();
            }

            //check whether in forest or city
            Type location = raptor.currentLocation.GetType();

            if (location.Equals(typeof(Forest)))
            {
                //give ending based off of what the user inputs
                if (input == "a")
                {
                    WriteLine("in the leaves");

                    if (raptor.inventory.Contains(food))
                    {
                        //ending 1
                        WriteLine("you've made it to your safe spot, perfectly camoflaged");
                        WriteLine("with enough food to last a good while");
                    }
                    else
                    {
                        //ending 2
                        WriteLine("you don't have any food to hide with in");
                        WriteLine("your safe spot and you get captured again");
                    }

                }
                else
                {
                    WriteLine("in the water");

                    if (raptor.inventory.Contains(weapon))
                    {
                        //ending 3
                        WriteLine("you chose to hide in the water, but with the");
                        WriteLine("weapons from the lab you brought along");
                        WriteLine("you get electrocuted in the process");
                    }
                    else
                    {
                        //ending 4
                        WriteLine("you chose the water where there's plenty of");
                        WriteLine("fish to chow on and to stay safe");
                    }
                }

            }else if (location.Equals(typeof(City)))
            {
                //give ending based off of what the user inputs
                if (input == "a")
                { 
                    WriteLine("in the alley");

                    if (raptor.inventory.Contains(food))
                    {
                        //ending 5
                        WriteLine("you hide in the alley with your food");
                        WriteLine("and make do with this secret hiding spot");
                    }
                    else
                    {
                        //ending 6
                        WriteLine("you can't camoflage well in the alley, thus you");
                        WriteLine("are easily captured in the process");
                    }
                }
                else
                {
                    WriteLine("in the street");

                    if (raptor.inventory.Contains(weapon))
                    {
                        //ending 7
                        WriteLine("you're easily detected in the streets with your weapons,");
                        WriteLine("and you get captured yet again");
                    }
                    else
                    {
                        //ending 8
                        WriteLine("you easily hide in the street where no one");
                        WriteLine("notices you; you're safe now");
                    }

                    nextLine();
                    WriteLine("The Game is over");
                    WriteLine("Thanks for playing!");
                }
            }
        }

        public bool IsEnd()
        {
            Type location = raptor.currentLocation.GetType();

            if (location.Equals(typeof(Forest)) || location.Equals(typeof(City)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool IsStorage()
        {
            Type location = raptor.currentLocation.GetType();

            if (location.Equals(typeof(Storage)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //names character
        public string nameCharacter()
        {
            WriteLine("What would you like to name this young Dino");
            return ReadLine();
        }

        //moves onto the next line
        private void nextLine()
        {
            Thread.Sleep(1);
            WriteLine("");
        }

        public void WriteLine(string input)
        {
            Thread.Sleep(100);
            Console.WriteLine(input);
        }

    }   
}
