﻿using System;
using System.Threading;
using static System.Console;

namespace DINO_RUN
{
    class City : Locations
    {
        public City(ConsoleColor color) : base(color)
        {
            name = "City";
            description = "Big, wide, full of buildings and streets";
            dest1 = null;
            dest2 = null;
        }

        public override void LocationMenu()
        {
            WriteLine("Where will you go?");
            WriteLine("A. The Alley");
            WriteLine("B. The Street");
        }
    }
}
