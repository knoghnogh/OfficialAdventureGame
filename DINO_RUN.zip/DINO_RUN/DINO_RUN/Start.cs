﻿using System;
using System.Threading;
using static System.Console;

namespace DINO_RUN
{
    class Start : Locations
    {
        private bool repeat;

        public Start(): base(ConsoleColor.Black)
        {
            repeat = false;
            name = "Start";
            description = "The Starting point of the game";
            dest1 = new Hallway(ConsoleColor.DarkBlue);
            dest2 = new Storage(ConsoleColor.DarkYellow);
        }

        public Start(ConsoleColor color) : base(color)
        {
            repeat = true;
            name = "Start";
            description = "You've been here before";
            dest1 = new Hallway(ConsoleColor.DarkBlue);
            dest2 = new Hallway(ConsoleColor.DarkBlue);
            
        }

        public override void LocationMenu()
        {
            if (repeat)
            {
                WriteLine("Where will you go?");
                WriteLine("A. Door 1");
                WriteLine("B. Door 1 (you already went through door 2)");
            }
            else
            {
                WriteLine("Where will you go?");
                WriteLine("A. Door 1");
                WriteLine("B. Door 2");
            }
        }
    }
}
