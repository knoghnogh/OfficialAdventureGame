﻿using System;
using System.Threading;
using static System.Console;

namespace DINO_RUN
{
    class Hallway : Locations
    {
        public Hallway(ConsoleColor color) : base(color)
        {
            name = "Hallway";
            description = "Takes you to two different exits";
            dest1 = new Forest(ConsoleColor.Green);
            dest2 = new City(ConsoleColor.DarkGray);
        }

        public override void LocationMenu()
        {
            WriteLine("Where will you go?");
            WriteLine("A. Door 1");
            WriteLine("B. Door 2");
        }
    }
}
