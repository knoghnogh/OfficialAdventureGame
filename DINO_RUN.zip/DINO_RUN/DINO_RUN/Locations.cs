﻿using System;
using System.Threading;
using static System.Console;

namespace DINO_RUN
{
    abstract class Locations
    {
        public string name;
        public string description;
        public ConsoleColor locationColor = new ConsoleColor();
        public Locations dest1;
        public Locations dest2;

        public Locations(ConsoleColor color)
        {
            locationColor = color;
        }

        public abstract void LocationMenu();

        public string About()
        {
            return $"{name}: {description}";
        }

        public void WriteLine(string input)
        {
            Thread.Sleep(100);
            Console.WriteLine(input);
        }
    }
}